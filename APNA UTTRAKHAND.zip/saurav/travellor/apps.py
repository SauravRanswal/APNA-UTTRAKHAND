from django.apps import AppConfig


class TravellorConfig(AppConfig):
    name = 'travellor'
